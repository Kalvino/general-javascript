# How to run the app
## clone the application: 

run `git clone https://github.com/Kalvino/logparser.git`
## Install the dependencies:

run `npm install`

## Parse and print error logs:

<!-- because of typescript show, the line has slight changes -->
'ts-node src/parser.ts --input ./app.log --output ./errors.json'